var express = require('express');
var router = express.Router();
var fs = require('fs');

var array = [];


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.get('/getInfo', function(req, res) {
	var i;
	console.log(req.query.data);
	var br = JSON.parse(req.query.data);
	for (i = 0; i < array.length; i++) {
		if (array[i].data == br.data){
			res.send(JSON.stringify(array[i]));
		}
	}
	res.send(JSON.stringify("NOT FOUND"));
	});
router.get('/postInfo', function(req, res) {
	console.log(req.query.data);
	var br = JSON.parse(req.query.data);
	array.push(br);
	console.log(array);
	fs.writeFile('ZapisaniyeDati.txt',JSON.stringify(array), 'utf8', () => {}); 
	res.send(200);
});


module.exports = router;
